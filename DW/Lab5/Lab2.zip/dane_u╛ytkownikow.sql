
        CREATE TABLE U�ytkownik (
            ID INT IDENTITY(1,1) PRIMARY KEY,
            Imie TEXT,
            Nazwisko TEXT,
        );
        
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mariusz', 'Ka�mierczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Iwo', 'Oleksa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymon', '�elasko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Oliwier', 'Cacko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymoteusz', 'Zygu�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Apolonia', 'Gumienna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eliza', 'Reszke');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sonia', 'Osial');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mi�osz', 'Misiejuk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marika', 'Wardza�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymon', 'Galik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Albert', 'Kolendo');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stefan', 'Strycharz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('J�drzej', 'Dobrosz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sandra', 'W�dka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mariusz', 'Dzier�ak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcelina', 'Miszta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gaja', 'Krzyka�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Micha�', 'Szmajda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Apolonia', 'Kolek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('�ukasz', 'Malcharek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Klara', 'Wojaczek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Borys', 'Wiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eryk', 'Franc');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nicole', 'Panu�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Robert', 'Pabi�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bruno', 'Bernatowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marianna', 'Mizak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cezary', 'Samson');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Lidia', 'Neska');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'Molka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Syka�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rados�aw', 'Lepianka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Borys', 'Westfal');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Artur', 'Matusewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nataniel', 'Wilma');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dorota', 'Suszka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fabian', 'Foit');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jerzy', 'Orwat');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Miko�aj', 'Kutera');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tomasz', 'Cybul');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marek', 'Ka�mierczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dawid', 'Andrys');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aleksander', 'Czerkies');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Grzegorz', '�ledzik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Karpik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Kapcia');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maciej', 'Dziuban');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Artur', 'O�liz�o');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamil', 'Kary�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Angelika', 'Skierka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jerzy', 'S�dej');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Iwo', 'Karczmarz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Agnieszka', 'Pianka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Kukier');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Dytrych');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gustaw', 'Kobry�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tomasz', 'Barto�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maksymilian', 'Dytrych');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mateusz', 'St�por');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bruno', 'Bednarowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gabriel', 'Przenios�o');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcin', 'Skoneczna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dagmara', '�adziak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymon', 'Drgas');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rados�aw', 'Kara');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nataniel', 'Kwinta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olaf', 'Pyszka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Lidia', 'P�ocharczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamil', 'Gajdzik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nicole', '�ugaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Miko�aj', 'Suchora');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fryderyk', 'Policht');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anna Maria', 'Bieniak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Klepka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krystian', 'Sajn�g');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Franciszek', 'Lesiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Natasza', 'Kurp');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ewa', 'Nurkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Filip', 'Nitkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sandra', 'Morcinek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tola', 'Bielat');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cyprian', 'Drost');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gaja', 'Tokaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rozalia', 'Jarema');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Szymon', 'Pajdak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eryk', 'Brachaczek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jakub', 'M�otek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marika', 'Skonieczka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Pawe�', 'Ellwart');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marika', 'Wandas');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Agnieszka', 'Pawlos');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Engel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olaf', 'Synak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sandra', 'Gral');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nataniel', 'Satora');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Karina', 'Romaniak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Arkadiusz', 'Szczot');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olga', 'Januchta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mateusz', 'Trzmiel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olga', 'Przenios�o');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julita', 'Lesner');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jakub', 'Murat');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aleksander', 'Parda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mariusz', 'Maciejko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcin', 'Janowiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stanis�aw', 'Maras');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Szczypek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kazimierz', 'Morawiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bartek', 'Chachaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marek', 'Pot�ga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krzysztof', 'Olkowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Albert', 'Wawrzynek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Apolonia', '�mieszek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Oliwier', 'Wowra');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ryszard', 'Magryta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jan', 'Malara');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jan', 'Nojek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marika', 'Orman');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Albert', 'Bojdo');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Wojtera');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kalina', 'Szumacher');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jerzy', 'Naro�ny');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adrian', 'Szumny');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Piotr', 'Paw');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', 'Spychaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julianna', 'Rorat');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dariusz', 'Pa�nik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcel', '�wi�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jan', 'Wnuczek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mariusz', 'Buszta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'B�bel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eryk', 'Mikosz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rados�aw', 'Pietrusiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Grzegorz', '�o�nierczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gabriel', 'Syldatk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gabriel', '�ugaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Artur', 'Matyszczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Piotr', 'Szumna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dagmara', 'Pa�ciak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jakub', 'Zwara');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Inga', 'W�dka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fryderyk', 'Moj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Agnieszka', 'Zapa�nik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Syldatk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Klara', 'Solarek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aleks', 'Z�otek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('�ukasz', 'Tereszkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', 'Bernatek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dominik', 'Sza�aj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konstanty', 'Szumna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Juliusz', 'Rejek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cyprian', 'Polnik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maks', 'Szyma�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Karina', 'Fidler');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marianna', 'Rozum');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ada', 'Frelek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aleks', 'Wittbrodt');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('�ukasz', 'Joniak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rafa�', 'Durys');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamil', 'Rzeszut');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Damian', 'Janisz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Micha�', 'Brzykcy');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jerzy', 'Ciesielczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bianka', 'Wiatrak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Hubert', 'Wajdzik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Justyna', 'Strz�pek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sara', 'Klemens');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Hubert', 'Postawa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Kutek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Leon', 'Maszkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konstanty', 'Powier�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sonia', 'Szatko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mateusz', 'Kudela');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'Komuda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Wojciech', 'Fico�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Artur', 'Adamiuk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Wojciech', 'Janoszek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Agnieszka', 'Graban');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gaja', 'Dyka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konstanty', '�wistek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mieszko', 'Matus');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kajetan', 'Zawartka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stefan', 'Trybus');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aurelia', 'Szymula');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Blanka', 'Dejneka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jerzy', 'Gruchot');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Startek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Janina', 'Gal');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marika', 'Rozmiarek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Pochro�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tomasz', 'Gosz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ignacy', 'Roma�czyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcel', 'Karczmarek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mateusz', 'Mainka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Liwia', 'Korzonek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gabriel', 'Kolek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rados�aw', 'Zacharek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adrian', 'Wota');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anna Maria', 'Masiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dagmara', 'Barej');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kajetan', 'Zawiasa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Blanka', 'Kamyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nataniel', 'Maras');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Angelika', 'Bogusiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gustaw', 'Dzia�o');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kornelia', 'Olkowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anastazja', 'Pastuszko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anastazja', 'Adamiuk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ada', 'Nowotka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kaja', 'Kornak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', 'Zybura');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marianna', 'Lempart');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Micha�', 'Szumna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jeremi', 'Serwach');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fryderyk', 'Groth');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kalina', 'Kazek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Michalkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Juliusz', 'Klamka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Danel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mieszko', 'Margol');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aurelia', 'Sycz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'Liso�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cezary', 'Przyby�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Justyna', 'Waraksa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Obuchowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julita', 'Achtelik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Apolonia', 'Opas');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Albert', 'Pawe�kiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('El�bieta', 'Wajdzik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcel', 'Greszta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tomasz', 'Bender');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Karina', 'Grab');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymoteusz', 'Worach');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'N�dzi');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Filiks');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aurelia', 'Smal');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Malwina', 'Zontek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cyprian', 'Mazik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Szymon', 'Kunda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Agnieszka', 'Ma�as');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Liwia', 'Hynek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aleks', 'Siedlik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krystyna', 'Smolec');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dariusz', 'Albin');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Juliusz', 'Pasierbek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aniela', 'Kostro');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maciej', 'Szemraj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aleks', 'Poniedzia�ek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'Bartocha');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Filip', 'Uryga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fryderyk', 'Kremer');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aurelia', 'Lelonek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Apolonia', 'S�onka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olaf', 'Caba�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Artur', 'Budniak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anna Maria', 'Kru�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maks', 'Jama');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kaja', 'Gorgol');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Borys', 'Delikat');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamil', 'Wyskiel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Pawe�', 'Sz�apa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maurycy', 'Marci�czyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', 'Stochel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Malwina', 'Szyjka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Szymon', 'Olbrych');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Kubaczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julian', 'Chodak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ernest', 'Grygo');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Leonard', 'Zi�ciak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Ka�wak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ernest', 'Margas');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nicole', 'Pedrycz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Leon', 'Kopy��');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Patryk', 'Borysewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mieszko', 'Gumienna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stanis�aw', 'Uss');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Forysiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Franciszek', 'Pszcz�ka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ewa', 'W�dka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rozalia', 'Ceynowa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stanis�aw', 'Kosak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Pawe�', 'Rembacz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Damian', 'Kosa�ka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mi�osz', 'Parda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ignacy', 'Banek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ewelina', 'Krekora');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Janina', 'Potoczek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bruno', 'Mitera');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Kandziora');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'Drywa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Pa�ciak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Monika', 'Pi�tkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Justyna', 'Maszota');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Juliusz', 'D�ubak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rozalia', 'Mas�o�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anna Maria', 'Pysz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Damian', 'Pitek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maks', 'Kaczmar');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Alex', 'Giero�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Melania', 'Dydak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Alan', 'Dziurla');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tomasz', 'Gogola');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eryk', 'Bembenek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olgierd', 'Bisaga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Hankiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dagmara', 'Palak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olga', 'Apostel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nela', 'Gi�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', '�elasko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jakub', 'Frydrychowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Emil', 'Dyszkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stefan', 'Pajdak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dawid', 'Kolanko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Owsiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', 'Hamera');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Albert', 'Apanowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nela', 'Amanowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marek', 'Radko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Juliusz', '�apaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcel', 'Piercha�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maks', 'Szczot');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Borys', 'Pastor');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ada', 'Iciek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mieszko', 'Broncel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olgierd', 'Biesaga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gabriel', 'W�jt');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ksawery', 'Szelest');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Hubert', 'Bender');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Oliwier', 'Dusik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymon', 'Wylega�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nikodem', 'Wiciak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'Ciak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Alex', 'Nieszporek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kazimierz', '�abno');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Grzegorz', '�ukasz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sara', 'Sieczko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anastazja', 'Szwaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Juliusz', 'Zato�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Justyna', 'Mordal');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dagmara', 'Holewa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kajetan', 'Kopy��');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maurycy', 'Kolarz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olgierd', 'Mijas');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nela', 'Betlej');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sebastian', 'Malara');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Pieszak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Franciszek', 'Grygo');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Melania', 'Ko�nik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olgierd', 'Hetma�czyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Iwo', 'B�a�ejczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcelina', 'W�sek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kornel', 'Palonek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Alex', 'Kondej');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mi�osz', 'Hennig');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krystyna', 'Kunysz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ewa', 'Karpik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcel', 'Skiepko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Pawe�', 'Kozon');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Justyna', 'Wojtanowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krystyna', 'Pale�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ida', 'Pelka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Leonard', 'Kycia');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marika', 'Trochimiuk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anastazja', '�wit');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jeremi', 'Pospiech');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nikodem', 'Madejczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stefan', 'Fijo�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcin', 'St�pak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gustaw', 'St�pak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymoteusz', 'Toma');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Wiktor', 'Halama');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Blanka', 'Nawrotek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Karol', 'Chadaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ksawery', 'Cebo');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olgierd', 'Chwalisz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Przemys�aw', 'Oleksak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('B�a�ej', 'Startek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julita', 'Sondej');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('J�drzej', 'Magier');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dominik', 'Labus');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Arkadiusz', 'Forma');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ksawery', 'Hanzel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ignacy', 'Husak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nataniel', 'Mi�tka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sara', 'Flisek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Karina', 'Glica');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jeremi', 'Saj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Melania', 'Czury�o');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Agnieszka', 'Sosn�wka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcel', 'Pindor');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bartek', 'Sprycha');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymoteusz', 'Martin');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('�ukasz', 'Maszota');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcin', 'Li�kiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Miko�aj', 'Z�bik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tobiasz', 'Polasik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nicole', 'Mycek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Blanka', 'M�ynarz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tola', 'Neubauer');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fryderyk', 'Kurp');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jeremi', 'Dzika');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Robert', 'Boruc');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adam', 'Maziarczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sonia', '�acina');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('J�zef', 'Juras');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mateusz', 'Kapera');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Emil', 'Szajna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Norbert', 'Doktor');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rados�aw', 'Szajda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Liwia', 'Cierpka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maciej', 'Kary�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Norbert', 'Klyta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Alex', 'Tondera');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Karina', 'Pyrkosz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Wo�oszyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olaf', 'Wawszczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sandra', 'Januchta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aurelia', 'Weso�y');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maciej', 'Gonsior');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maurycy', 'Golak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Klara', 'Jop');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kalina', 'Gogola');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sonia', 'Burdach');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Hubert', 'Kunda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anna Maria', 'Gaw�owicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rados�aw', 'Hankiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kornel', 'Danel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('R�a', 'Szott');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Daniel', '�miel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konstanty', 'Gleba');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sara', 'Bodzak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fryderyk', 'Korda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sara', 'Moneta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamil', 'Klinger');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Franciszek', 'Kurc');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Haremza');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konrad', 'Idzi');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rafa�', 'Mrotek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nicole', 'Komisarczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tola', 'Kr�likiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jerzy', 'Owczarczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marek', 'Zaucha');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'Zyga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Pawe�', 'Wojtarowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sandra', 'Przenios�o');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Damian', 'Ernst');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stanis�aw', 'Bona');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Inga', 'Dyja');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eryk', '�y�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Wac�awiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marika', '�ukowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julian', 'Paliga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sylwia', 'Jeszke');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stefan', 'Latuszek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ignacy', 'Kude�ka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Filip', 'Januszko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kornel', 'Kielan');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eliza', 'Budych');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mariusz', 'Ma�ocha');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcelina', 'Tatarczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('J�zef', 'Je�yk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rados�aw', 'Stark');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Albert', 'Skiepko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anna Maria', 'Thiel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kazimierz', 'Szywa�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nikodem', 'Jaszczyszyn');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ewelina', 'Andrzejuk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Norbert', 'Ficner');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Oliwier', '��kiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Klara', 'Wiaderek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jacek', 'Szylar');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bartek', 'Tabi�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kalina', 'Jakimiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Agnieszka', 'Gajcy');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rozalia', 'Pajek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tola', 'Pawlukiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maks', 'Jarmu�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Liwia', 'Kocaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Karina', 'Ziemkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aurelia', 'Kubowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mariusz', 'J�draszczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kalina', 'Borczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Alan', 'Kierepka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Arkadiusz', 'Holeksa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamil', 'Matwiejczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Giedroj�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adam', 'Kosa�ka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Wawak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nela', 'Dejneka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adrianna', 'Kuliberda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marek', 'Filek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sara', 'Wajer');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olga', 'Dziadkowiec');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('El�bieta', 'Czerepak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krystyna', 'Uliczka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Pawe�', 'Sad�ocha');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tola', 'Krzosek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jakub', 'Armata');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maks', 'Walkusz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fryderyk', 'Aleksander');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nataniel', 'Wo�niak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Leonard', 'Szymk�w');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ryszard', 'Wac�awczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adam', 'Przewo�nik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dariusz', 'Stelmasiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dagmara', 'Kubasiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gaja', 'Dziarmaga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olga', '�acina');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Daniel', 'Miko�ajewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dorota', 'Tryka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rozalia', 'Zwi�zek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konstanty', 'Deneka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Stochaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tobiasz', 'Pielech');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rozalia', 'Pancerz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'Kubrak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stanis�aw', 'Jakimiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Justyna', 'Grabas');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Blanka', '�wierad');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Agnieszka', 'Woszczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eryk', 'Kajak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mieszko', 'Wyciszkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Szymon', 'Rezmer');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rozalia', 'Gumieniak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('J�drzej', 'Wardziak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sandra', 'Grabczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dorota', 'Frydrychowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olga', 'Boruc');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anita', 'Glonek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krystian', 'Oszust');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kalina', 'Brz�ka�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Mandrysz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bianka', 'Szumna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Natan', 'Mazanek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olga', 'Armata');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kajetan', 'Ma�yszka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sylwia', 'Zawodnik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'Wi�c�awek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aleks', 'Towarek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rafa�', 'Job');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rados�aw', 'Jandu�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ernest', 'Ceg�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ida', '�asak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maciej', 'Kulus');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Norbert', '�odyga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Iwo', 'Manista');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Piotr', 'Bazyd�o');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sonia', 'Lenc');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anna Maria', 'Wo�niak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olgierd', 'Kopik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ida', 'Neubauer');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dagmara', 'K�sek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Angelika', 'Koronkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kajetan', 'Bryzek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Arkadiusz', 'Gabryelczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mateusz', 'G�rnisiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sonia', 'Borejko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tobiasz', 'Lew');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gabriel', 'Sanetra');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('El�bieta', 'Klemczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bartek', 'Smykla');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Justyna', 'Pezda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Natan', 'Barankiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sebastian', 'Chomik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Justyna', 'Armatys');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'Wawrzkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('B�a�ej', 'Letkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Liwia', 'Jama');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Agnieszka', 'Wa��sa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Wiktor', 'Dorna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ada', 'Chyb');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eryk', 'Kieszek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Klara', 'Marchlewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fabian', 'Maciejko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jeremi', '�wistek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Angelika', 'Kycia');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maksymilian', 'Zbroja');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Natasza', 'Suchta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olgierd', 'Ma�as');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fryderyk', 'Chachaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rafa�', 'Kenig');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mi�osz', 'Szczap');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Kalota');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Robert', 'Siemion');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Miko�aj', 'Cacko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Apolonia', 'G�siarz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jakub', 'Dziadkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Angelika', 'Jacak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Malwina', 'Raczkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Oliwier', 'Jas');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bruno', 'Palus');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marika', 'Ksel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'Cudzich');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sebastian', 'Fry�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('B�a�ej', '�wiech');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dominik', 'Wygoda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julianna', 'Przybycie�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nela', 'Wojtera');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nela', 'Hulb�j');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('J�zef', 'Sorbian');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olaf', 'Tokarek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rozalia', 'Osojca');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Oskar', 'Ma�ysiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Patryk', 'Marosz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tomasz', 'Gamrat');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Ros�on');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adrian', 'M�ocek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dorota', 'Majtyka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Buchholz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marianna', 'W�sek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Angelika', 'Prucnal');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tobiasz', 'Chromy');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Arkadiusz', 'Janiga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anastazja', 'Swaczyna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mateusz', 'Zajko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rados�aw', 'Sadura');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Melania', 'Mordak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Go�ofit');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maksymilian', 'Lesik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kornelia', 'Gryga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adrianna', 'Ros�o�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olaf', 'Wijata');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Arkadiusz', 'Parda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dominik', 'Gul');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Albert', 'Chmielak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mi�osz', 'Preuss');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tomasz', 'Huber');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krystyna', 'Jakimiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Norbert', 'Giedroj�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sandra', 'Buszka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dagmara', 'Wabik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Wojciech', '��kiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stanis�aw', 'Szajna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Liwia', 'Kutera');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Piotr', 'Holewa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'So�ek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Albert', 'Cz�onka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Alex', '�uksza');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'Bia�k');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Apolonia', 'Sa�uda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nicole', 'Gradek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Malwina', 'Malewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'Krzysztofek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Angelika', 'Solich');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eliza', 'Betlej');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nikodem', 'Maksimowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adrian', '�akiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aurelia', 'Ciereszko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bruno', 'Niedo�pia�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anna Maria', 'Kazana');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mateusz', 'Czura');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Karol', 'Bejma');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Inga', 'Ok�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamil', 'Byra');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ida', 'Wocial');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Mularz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mariusz', 'Aleksander');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marianna', 'Linkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kajetan', 'Albin');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('El�bieta', 'Bak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anna Maria', 'Gog�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dagmara', 'Kamyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kazimierz', 'J�zefczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Pawe�', 'Lenc');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Hermanowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cezary', 'Wawrzonek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mieszko', 'Hendzel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Robert', 'Huczko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Pawe�', 'Doroz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marek', 'Huber');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jeremi', 'Goska');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Justyna', 'Parzyszek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'Rapa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Wojciech', 'Kondej');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'Detka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sebastian', 'Stelmasiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Melania', 'Pot�ga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ignacy', 'D�browicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sandra', 'Kuzia');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bianka', 'Wylega�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anita', 'J�drzejek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kornelia', 'Bejger');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Miko�aj', 'Kenig');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aniela', 'Fiedoruk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dorota', 'G�sienica');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Damian', 'Zadworny');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Malwina', 'Pesta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('R�a', 'Poleszak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jacek', 'Wiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('El�bieta', 'Sznura');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Alex', 'Martynowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ewelina', 'Garczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Grzegorz', 'Tabi�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Juliusz', '�apacz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sandra', '�wi�s');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kornel', 'Salwin');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Janina', 'Pietrus');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ryszard', 'S�upek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kornelia', 'Kursa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Labocha');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', 'Suda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Szmaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ernest', 'Mazanek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'Brodawka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sara', 'Skotarek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Goliasz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konstanty', 'Krzeszowiec');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maksymilian', 'Danilczuk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', 'Kazimierczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kajetan', 'Lamch');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Alex', '��kiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nicole', 'Dykas');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maks', 'Golon');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kazimierz', 'Prawdzik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Artur', 'Gasz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mateusz', 'Trochim');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tadeusz', 'Bzymek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Natan', 'Chodak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Natan', 'Lepa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Blanka', 'Wyderka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bianka', 'Maszczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ernest', 'Jakiel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bianka', 'Przyby�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ada', 'Kazimierczuk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kajetan', 'Porzucek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mariusz', 'Krzosek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Filip', 'Ko�ciuszko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Leonard', 'Leszczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anastazja', 'Laszkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maciej', 'Tomaszuk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Leon', 'Lenda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('B�a�ej', 'Borkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cezary', 'Noculak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rados�aw', 'Boba');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('J�drzej', 'Meissner');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eliza', 'Muzyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Oliwier', 'Jop');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jakub', 'Bazyluk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Pawe�', 'Babij');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dominik', 'Bulczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mi�osz', 'Samoraj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Oskroba');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Inga', 'Wierzcho�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mieszko', '�mija');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gustaw', 'Dudko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jacek', 'Patyna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('J�zef', 'Oleksik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dominik', 'Baum');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adam', 'Str�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maks', 'Grabo�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mi�osz', 'St�j');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Przemys�aw', 'Bartoszak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sylwia', 'Olszowa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aleks', 'Lang');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Artur', 'B�bol');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dominik', 'Zbylut');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Melania', 'Job');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maks', 'Krystkowiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('R�a', 'Dudzicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Oskar', 'Pikor');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('J�zef', 'D�ugajczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konrad', 'Ga�at');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krystyna', 'Lato');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aniela', 'Sprycha');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fabian', '�odyga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Norbert', '�l�czka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Janina', 'Helak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konstanty', 'Drewa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Grzegorz', 'Karwala');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Maksymilian', 'Gmur');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('El�bieta', 'Joniak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Angelika', 'Plona');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jakub', 'Kielczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Karol', 'Zagrodnik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kaja', 'Kursa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mieszko', 'Bat�g');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Dar�ak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nela', 'Pleskot');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gabriel', 'Stasica');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Franciszek', 'Bajko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('B�a�ej', 'Oleksik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Araszkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Damian', 'Fijak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julita', '�uszczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', 'S�owiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('El�bieta', 'Wizner');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kalina', 'Szylar');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Liwia', 'Zubel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Justyna', 'Fico�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Emil', 'Kruzel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rafa�', 'Linek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olaf', 'Kopyto');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dorota', 'Naczk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Lelito');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('�ukasz', 'Dylak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aniela', 'Giel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bruno', 'Hanus');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Piechna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cyprian', 'Widuch');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamil', 'Karmelita');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stanis�aw', 'Jereczek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dariusz', 'Liedtke');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Janina', 'Strz�da�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Karol', 'Szumna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Inga', 'Star�ga');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Arkadiusz', 'Z�bik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eryk', 'Kopyto');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Mica�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Albert', 'Bak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcel', 'Trojanek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nicole', 'Goska');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nela', 'Megger');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Juliusz', 'Keler');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Micha�', 'Wolan');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Iwo', 'Chwalisz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Leon', 'Myszor');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('�ukasz', 'Martyka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ernest', 'Ruman');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dominik', 'Chatys');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Kurz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Melania', 'Gmurczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Malwina', 'Grabczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marianna', 'Ma�lach');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Natasza', 'Palus');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Grzegorz', 'Gadza�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Leon', 'T�rz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marcelina', 'Szczerbiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Liwia', 'S�oboda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dariusz', '�wiech');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Szymon', 'Joniak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Wiktor', 'Korkosz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Alan', 'Polaszek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julian', 'Klinkosz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Szymon', 'Gogacz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Borys', 'Tylman');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ignacy', 'Ko�ak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gaja', 'Ha�ka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olga', 'Knysak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Malwina', 'Dankiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Frydrychowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rozalia', 'Lazarek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mariusz', 'Wo�kowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kacper', 'Pitala');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Fabian', 'Wijata');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adrian', 'Ledzion');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Inga', 'Kalista');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jakub', 'Olszowa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymon', 'Husak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'Bazyd�o');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ada', 'Praczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('B�a�ej', 'Michnowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ksawery', 'Sypie�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anastazja', 'Ceynowa');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olgierd', 'Ciso�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jan', 'Twardy');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', '�ugaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('B�a�ej', 'Zapadka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymon', 'St�pak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Grzegorz', 'Pasztaleniec');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sebastian', 'Skalik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ida', 'Ziegler');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sandra', 'Zarzeczna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anita', 'Bogda�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Blanka', 'Morcinek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kajetan', 'Tondera');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kalina', 'Dworczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marianna', 'Bere�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Filip', 'Gietka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kajetan', 'Wac');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kornelia', 'Wojew�dka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dawid', 'Bakun');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jan', 'Matusewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adam', 'Ku�wik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Agnieszka', 'Osiadacz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mieszko', 'Tarasek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nela', 'Labudda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jacek', 'Melcer');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anna Maria', 'Szybiak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krystyna', 'Sklorz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Kulon');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gaja', 'Sta�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aleks', 'Mich');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Antoni', 'Majorek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gaja', 'Erdmann');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Inga', 'Skolik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jeremi', 'Duszczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dawid', 'Klin');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'Bobryk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nikodem', 'Dy�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymon', 'Godzik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dagmara', 'Kieloch');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marika', 'Komuda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Malecha');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eliza', 'Kuzior');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Robert', 'Wota');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymon', 'Pyrz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ida', 'Le�ko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tola', 'Zato�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julianna', '�epek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konrad', '�yczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bruno', 'Plona');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nikodem', 'Jasionek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Wiktor', 'Wojew�dka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cezary', 'Jeszka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gabriel', 'Solis');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anastazja', 'Gierasimiuk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Miko�aj', 'Grab');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cezary', 'Maksym');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Buza');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Kapka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mateusz', 'Siedlaczek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stanis�aw', 'Michalczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Emil', 'Nehring');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('B�a�ej', 'Bat�g');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nataniel', 'Golonko');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Styn');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Emil', 'Dub');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Tymoteusz', 'Szmagaj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamil', '�mieja');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ignacy', 'Raszkiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Jakub', 'Dzidek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stanis�aw', 'P�drak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Juliusz', 'Klamka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Klara', 'Strojna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'Kalka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', 'Skocz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Anastazja', 'Szywa�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adrianna', 'Roso�ek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Olgierd', 'Fogel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nela', 'Ko�ciesza');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Monika', 'Sporek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', 'Golenia');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ryszard', 'Michnik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamil', 'Kozica');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Grzegorz', 'Duc');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ada', 'Dybiec');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Igor', 'Cherek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julianna', 'Szczepaniec');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mariusz', 'Lato');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bianka', 'Misiarz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Franciszek', 'Kuczak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dariusz', '�aszczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'Fyda');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cyprian', 'Majczyna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ignacy', 'Florian');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Justyna', 'Maculewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Stanis�aw', 'Tomaszuk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Iwo', 'Ko�aczek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Agnieszka', 'Ellwart');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Rados�aw', 'Handzel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Galek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Wiktor', 'Zgo�a');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Cezary', 'Suchenek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julita', 'Witkowicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Eliza', 'Gogola');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bianka', 'Lepka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gustaw', 'Brachman');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nicole', 'Syroka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Wocial');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Nied�wiadek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bartek', 'Bernard');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ryszard', 'Durma');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('R�a', 'Futyma');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Inga', 'Cio�czyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ksawery', 'Hamera');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Czupryn');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Nataniel', 'Marchlewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Gaja', 'Wac�awczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Bruno', 'Skomra');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adrian', '�uszczyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Smor�g');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Mariusz', 'W�js');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Lidia', 'Ga�');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Adrianna', 'Ko�ciukiewicz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Ryszard', 'Omiotek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('J�drzej', 'Kaletka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konstanty', 'Rabiej');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Sandra', 'Ostapczuk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Marek', 'Smagacz');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Urszula', 'Delekta');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Konstanty', 'Cio�czyk');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Malwina', 'Jamro�y');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Przemys�aw', '�wi�s');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('R�a', 'Martin');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Roksana', 'Rychcik');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krzysztof', 'Meler');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Blanka', 'Sm�tek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Robert', 'Szemraj');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Kamila', 'Fura');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Klara', 'Trznadel');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Janina', 'Wo�niak');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Przemys�aw', 'M�otek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Witold', 'Cywka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Andrzej', 'Szulist');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Aleksander', '�awniczek');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Julita', 'Szajna');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Dorota', 'Nag�rka');
            
            INSERT INTO U�ytkownik (Imie, Nazwisko)
            VALUES ('Krystian', 'Dulewicz');
            