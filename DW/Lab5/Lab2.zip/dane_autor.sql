
        CREATE TABLE Autor (
            ID INT IDENTITY(1,1) PRIMARY KEY,
            Imi� TEXT,
            Nazwisko TEXT,
        );
        
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Janina', 'Sabak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Marika', 'Koniec');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Leon', 'Wiese');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Karina', 'Jeszka');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Anita', 'Marko');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Oliwier', 'Tylec');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Julian', 'Hamerla');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Jan', 'Szkaradek');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Dawid', 'Kmak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Andrzej', '�ukowicz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Ada', 'Madzia');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Ada', 'Szczepan');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Natan', 'Cydzik');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Malwina', 'Pasich');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Dawid', 'Misiejuk');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Dariusz', 'Nurkiewicz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('J�drzej', '�uberek');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Karol', 'Polaszek');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Aleksander', 'Kiryluk');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Cyprian', 'Pronobis');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Krzysztof', 'Krauz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Anastazja', 'Wyrwa�');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Dominik', 'Wilusz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Julianna', 'Guziak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Krystian', 'Majdak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Stefan', 'Dawiec');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Tola', 'Gomo�a');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Albert', 'Wysota');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Alan', 'Leszkiewicz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Ksawery', 'Misiaszek');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Stefan', 'Bona');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Tymon', 'Klemczak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Grzegorz', 'Postawa');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Sonia', 'Pielka');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Nikodem', 'Dzienis');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Tymoteusz', 'Migda');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Adam', 'Cheba');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Jan', 'Witko');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Maurycy', 'Raba');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Szymon', 'B�a�ejewicz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Kornelia', 'J�drys');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Marek', 'Maciocha');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Krystyna', 'Holc');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Grzegorz', 'Szczap');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Krystian', 'Br�zda');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Aleks', 'Smagacz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Dorota', 'Kurzac');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Ignacy', 'Buszko');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Bianka', 'Kulma');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Dorota', 'Leszczak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Natan', 'Gerlach');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Krzysztof', 'Przenios�o');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Jacek', 'Thomas');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Ernest', 'Golczyk');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Inga', 'Ornat');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Kalina', 'Niebudek');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Szymon', 'Stawczyk');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Ksawery', 'Wiraszka');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Urszula', 'Dudkowiak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Witold', 'Hada�a');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Kamila', 'Wypch�o');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Marika', 'Maciuszek');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Norbert', 'Korzeniak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Jacek', 'Chmielak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Gaja', 'Fiedoruk');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Anna Maria', 'Mi�kowiec');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Arkadiusz', '�uberek');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Natan', 'Nicewicz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Igor', 'Dzier�ak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Eryk', 'Dej');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Igor', 'Ziarno');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Bianka', 'Ufniarz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Janina', 'Wicha');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Konrad', 'Lisak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Igor', 'Ko�ata');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Monika', 'Sobi�o');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Arkadiusz', 'Kolbusz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Oskar', 'Wicha');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Angelika', 'Bodzak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Natan', 'Linkiewicz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('J�zef', 'Ka�mierczyk');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Bartek', 'Kwak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Malwina', 'Weremczuk');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Bianka', 'Gal');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Lidia', 'Koss');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Dominik', 'Sochaj');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Liwia', 'Gorgol');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Maciej', 'Klinkosz');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Oskar', '�okietek');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Konrad', 'Bereda');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Marcelina', 'Chomiak');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Witold', 'Weso�y');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Przemys�aw', '�witaj');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Mariusz', 'Obia�a');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Maksymilian', 'Turo�');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Kamila', 'Mojsa');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Hubert', 'Wola�czyk');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Fabian', 'Kosiec');
            
            INSERT INTO Autor (Imi�, Nazwisko)
            VALUES ('Liwia', 'Zeman');
            