
            CREATE TABLE Autor_Kurs (
                ID_Autor INTEGER,
                ID_Kurs INTEGER,
				FOREIGN KEY (ID_Autor) REFERENCES Autor(ID),
				FOREIGN KEY (ID_Kurs) REFERENCES Kurs(ID)
            );
            
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (2, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (2, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (2, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (3, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (3, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (3, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (4, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (4, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (4, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (5, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (6, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (7, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (7, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (8, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (8, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (8, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (9, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (9, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (10, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (11, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (11, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (11, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (12, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (12, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (13, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (13, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (13, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (14, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (14, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (15, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (16, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (16, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (16, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (17, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (18, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (18, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (18, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (19, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (19, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (20, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (21, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (22, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (22, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (22, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (23, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (23, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (23, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (24, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (24, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (25, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (25, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (26, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (26, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (27, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (27, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (28, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (29, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (30, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (31, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (31, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (31, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (32, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (32, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (33, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (33, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (33, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (34, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (34, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (34, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (35, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (35, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (36, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (36, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (36, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (37, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (37, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (37, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (38, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (39, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (40, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (41, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (42, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (43, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (43, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (44, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (45, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (45, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (45, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (46, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (46, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (46, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (47, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (48, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (48, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (48, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (49, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (50, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (51, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (52, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (53, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (54, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (54, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (54, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (55, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (56, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (57, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (57, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (58, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (59, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (59, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (59, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (60, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (60, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (61, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (62, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (63, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (63, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (64, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (64, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (64, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (65, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (66, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (66, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (66, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (67, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (68, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (68, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (68, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (69, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (69, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (69, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (70, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (71, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (72, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (72, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (72, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (73, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (74, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (74, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (74, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (75, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (75, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (76, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (77, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (78, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (78, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (78, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (79, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (80, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (81, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (82, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (83, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (83, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (84, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (85, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (85, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (86, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (86, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (86, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (87, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (87, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (87, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (88, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (88, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (89, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (89, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (89, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (90, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (90, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (91, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (91, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (91, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (92, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (92, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (92, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (93, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (93, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (93, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (94, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (94, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (94, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (95, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (96, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (96, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (97, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (97, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (97, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (98, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (98, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (99, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (99, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (100, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (100, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (100, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (101, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (101, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (101, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (102, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (102, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (103, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (103, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (104, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (104, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (104, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (105, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (106, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (107, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (107, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (108, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (109, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (109, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (110, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (110, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (111, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (111, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (112, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (112, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (113, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (113, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (113, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (114, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (115, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (115, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (116, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (116, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (116, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (117, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (118, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (119, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (119, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (120, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (120, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (120, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (121, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (121, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (121, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (122, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (122, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (123, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (124, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (125, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (125, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (126, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (126, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (127, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (127, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (128, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (129, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (129, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (129, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (130, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (130, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (130, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (131, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (131, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (131, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (132, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (132, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (133, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (133, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (134, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (134, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (135, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (136, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (136, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (136, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (137, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (137, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (137, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (138, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (139, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (140, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (141, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (141, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (141, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (142, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (142, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (143, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (144, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (144, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (144, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (145, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (145, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (145, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (146, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (146, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (147, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (147, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (147, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (148, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (148, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (149, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (150, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (151, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (151, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (152, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (152, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (153, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (153, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (154, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (154, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (155, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (155, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (155, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (156, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (157, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (158, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (158, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (159, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (159, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (160, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (161, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (162, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (162, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (163, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (163, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (163, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (164, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (164, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (165, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (165, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (165, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (166, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (167, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (168, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (169, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (169, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (170, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (170, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (171, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (171, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (172, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (173, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (174, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (175, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (175, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (175, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (176, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (177, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (178, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (178, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (179, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (179, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (179, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (180, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (180, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (180, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (181, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (182, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (182, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (182, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (183, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (183, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (184, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (185, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (185, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (186, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (186, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (187, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (187, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (187, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (188, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (188, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (188, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (189, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (190, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (190, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (191, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (191, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (192, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (192, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (193, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (193, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (194, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (194, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (195, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (196, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (196, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (196, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (197, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (197, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (197, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (198, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (199, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (200, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (201, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (201, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (202, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (202, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (203, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (203, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (203, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (204, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (205, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (206, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (206, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (206, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (207, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (207, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (207, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (208, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (208, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (209, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (210, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (211, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (211, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (211, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (212, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (213, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (214, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (215, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (215, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (215, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (216, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (216, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (217, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (217, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (218, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (219, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (220, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (221, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (221, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (221, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (222, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (222, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (223, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (223, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (224, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (224, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (225, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (225, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (225, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (226, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (226, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (227, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (227, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (228, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (228, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (228, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (229, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (229, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (229, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (230, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (231, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (231, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (231, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (232, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (232, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (232, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (233, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (234, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (235, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (235, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (235, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (236, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (237, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (238, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (239, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (239, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (239, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (240, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (241, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (241, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (242, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (242, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (243, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (243, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (243, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (244, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (244, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (244, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (245, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (245, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (245, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (246, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (247, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (248, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (248, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (249, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (249, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (250, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (250, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (250, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (251, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (251, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (251, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (252, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (253, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (254, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (254, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (255, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (255, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (256, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (256, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (256, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (257, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (257, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (258, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (258, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (258, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (259, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (259, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (260, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (260, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (260, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (261, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (261, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (262, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (262, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (262, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (263, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (264, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (264, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (265, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (265, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (265, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (266, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (266, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (267, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (267, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (267, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (268, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (268, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (268, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (269, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (269, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (269, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (270, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (271, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (272, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (272, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (273, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (274, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (275, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (275, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (276, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (276, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (277, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (277, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (277, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (278, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (278, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (279, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (280, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (280, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (281, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (281, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (281, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (282, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (282, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (282, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (283, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (284, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (285, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (285, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (286, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (287, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (288, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (288, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (289, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (289, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (290, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (290, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (291, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (291, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (292, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (292, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (292, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (293, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (294, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (294, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (295, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (296, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (296, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (297, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (298, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (298, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (299, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (299, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (300, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (300, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (301, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (301, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (302, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (303, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (303, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (303, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (304, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (305, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (305, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (306, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (307, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (308, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (308, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (308, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (309, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (309, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (310, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (310, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (311, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (311, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (312, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (312, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (313, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (313, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (314, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (314, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (315, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (315, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (315, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (316, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (316, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (317, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (317, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (318, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (319, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (320, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (320, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (320, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (321, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (321, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (322, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (323, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (323, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (324, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (325, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (326, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (326, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (326, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (327, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (327, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (328, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (328, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (328, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (329, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (329, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (330, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (331, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (331, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (332, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (332, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (333, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (333, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (334, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (334, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (335, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (335, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (336, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (336, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (336, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (337, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (337, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (338, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (338, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (338, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (339, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (339, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (340, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (340, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (341, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (341, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (341, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (342, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (342, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (342, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (343, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (343, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (343, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (344, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (344, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (345, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (345, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (345, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (346, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (346, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (347, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (348, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (349, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (349, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (349, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (350, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (350, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (350, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (351, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (352, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (352, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (352, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (353, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (354, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (355, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (355, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (356, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (356, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (356, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (357, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (357, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (357, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (358, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (358, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (358, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (359, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (359, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (359, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (360, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (360, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (360, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (361, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (361, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (361, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (362, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (362, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (363, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (363, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (363, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (364, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (364, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (364, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (365, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (365, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (365, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (366, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (366, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (367, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (367, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (367, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (368, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (368, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (369, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (369, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (369, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (370, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (370, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (370, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (371, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (371, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (372, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (373, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (373, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (374, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (375, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (375, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (376, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (376, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (376, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (377, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (377, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (378, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (378, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (378, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (379, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (380, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (380, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (380, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (381, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (382, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (382, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (383, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (384, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (384, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (385, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (386, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (386, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (386, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (387, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (387, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (387, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (388, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (388, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (388, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (389, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (390, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (390, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (391, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (391, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (391, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (392, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (392, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (393, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (393, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (394, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (395, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (395, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (396, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (396, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (396, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (397, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (397, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (398, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (399, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (399, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (400, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (400, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (401, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (402, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (402, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (403, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (403, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (404, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (404, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (405, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (406, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (406, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (406, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (407, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (408, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (408, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (409, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (409, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (410, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (410, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (410, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (411, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (412, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (412, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (412, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (413, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (413, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (413, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (414, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (414, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (415, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (415, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (415, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (416, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (416, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (417, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (417, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (418, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (419, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (419, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (419, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (420, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (420, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (421, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (421, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (421, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (422, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (423, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (424, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (425, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (425, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (426, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (426, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (427, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (428, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (428, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (429, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (429, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (429, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (430, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (430, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (430, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (431, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (432, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (432, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (433, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (434, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (435, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (435, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (436, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (436, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (437, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (437, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (438, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (438, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (439, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (440, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (440, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (441, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (441, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (442, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (442, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (442, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (443, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (444, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (444, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (445, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (446, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (446, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (447, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (448, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (448, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (448, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (449, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (450, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (450, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (451, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (451, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (451, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (452, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (452, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (453, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (453, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (454, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (454, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (454, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (455, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (455, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (455, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (456, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (456, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (457, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (457, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (458, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (459, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (459, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (460, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (460, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (461, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (461, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (462, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (463, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (464, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (464, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (465, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (466, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (466, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (466, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (467, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (468, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (468, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (469, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (469, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (469, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (470, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (471, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (471, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (471, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (472, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (472, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (473, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (474, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (475, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (476, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (476, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (476, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (477, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (477, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (477, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (478, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (478, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (478, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (479, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (480, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (481, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (481, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (482, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (482, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (482, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (483, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (483, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (483, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (484, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (484, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (484, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (485, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (486, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (486, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (486, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (487, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (488, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (488, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (489, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (490, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (491, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (491, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (492, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (492, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (492, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (493, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (494, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (495, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (495, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (495, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (496, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (496, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (497, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (497, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (497, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (498, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (498, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (499, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (500, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (500, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (501, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (501, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (502, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (502, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (503, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (503, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (503, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (504, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (504, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (504, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (505, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (505, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (505, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (506, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (506, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (507, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (508, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (508, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (508, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (509, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (509, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (509, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (510, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (511, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (511, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (512, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (512, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (512, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (513, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (513, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (514, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (514, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (514, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (515, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (515, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (516, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (516, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (516, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (517, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (517, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (517, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (518, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (518, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (518, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (519, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (519, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (519, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (520, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (520, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (520, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (521, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (522, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (522, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (522, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (523, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (524, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (524, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (525, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (525, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (526, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (526, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (527, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (527, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (528, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (528, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (529, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (530, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (530, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (530, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (531, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (531, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (531, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (532, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (532, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (533, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (534, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (535, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (535, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (535, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (536, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (537, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (538, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (539, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (539, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (540, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (540, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (541, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (541, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (542, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (543, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (544, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (545, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (545, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (545, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (546, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (546, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (546, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (547, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (548, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (548, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (549, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (549, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (550, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (550, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (550, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (551, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (551, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (552, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (552, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (553, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (554, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (554, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (554, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (555, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (555, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (555, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (556, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (556, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (557, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (557, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (558, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (558, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (559, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (560, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (561, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (561, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (562, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (562, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (562, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (563, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (563, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (564, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (564, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (564, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (565, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (565, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (565, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (566, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (567, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (567, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (568, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (568, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (569, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (570, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (571, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (571, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (572, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (572, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (573, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (573, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (574, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (574, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (575, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (575, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (575, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (576, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (577, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (578, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (578, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (579, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (579, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (580, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (580, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (581, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (581, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (581, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (582, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (582, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (582, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (583, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (584, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (584, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (585, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (586, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (587, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (588, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (589, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (589, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (589, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (590, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (590, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (590, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (591, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (591, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (591, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (592, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (592, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (593, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (593, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (594, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (594, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (594, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (595, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (596, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (596, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (596, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (597, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (598, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (598, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (599, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (599, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (599, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (600, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (601, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (601, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (601, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (602, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (602, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (602, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (603, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (604, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (605, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (605, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (605, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (606, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (606, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (607, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (607, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (607, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (608, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (608, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (608, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (609, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (609, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (609, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (610, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (611, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (611, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (611, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (612, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (612, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (613, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (613, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (614, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (615, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (616, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (616, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (616, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (617, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (618, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (619, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (619, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (619, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (620, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (620, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (620, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (621, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (622, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (623, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (623, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (624, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (625, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (626, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (626, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (627, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (627, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (627, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (628, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (629, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (629, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (629, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (630, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (630, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (630, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (631, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (632, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (632, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (633, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (633, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (634, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (634, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (635, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (636, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (636, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (636, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (637, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (637, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (638, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (638, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (638, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (639, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (639, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (640, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (640, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (640, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (641, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (641, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (641, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (642, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (642, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (643, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (643, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (643, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (644, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (645, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (645, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (645, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (646, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (646, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (646, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (647, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (647, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (647, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (648, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (648, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (649, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (650, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (650, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (650, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (651, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (652, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (652, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (653, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (653, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (654, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (655, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (655, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (655, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (656, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (657, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (657, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (658, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (659, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (659, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (660, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (660, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (661, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (661, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (662, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (662, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (662, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (663, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (663, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (663, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (664, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (665, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (665, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (665, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (666, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (667, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (667, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (668, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (668, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (669, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (669, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (670, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (671, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (672, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (672, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (673, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (673, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (673, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (674, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (674, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (674, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (675, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (675, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (675, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (676, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (676, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (676, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (677, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (677, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (677, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (678, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (679, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (680, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (680, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (681, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (681, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (681, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (682, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (683, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (684, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (684, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (685, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (685, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (685, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (686, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (687, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (688, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (688, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (688, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (689, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (689, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (690, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (690, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (691, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (692, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (692, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (693, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (693, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (694, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (695, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (696, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (696, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (696, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (697, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (698, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (699, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (700, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (700, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (701, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (701, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (702, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (703, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (703, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (704, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (704, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (704, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (705, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (705, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (706, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (707, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (707, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (708, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (708, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (709, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (709, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (710, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (711, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (711, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (712, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (713, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (713, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (714, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (714, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (714, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (715, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (715, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (716, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (717, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (717, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (717, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (718, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (718, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (719, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (720, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (721, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (721, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (721, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (722, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (722, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (723, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (724, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (724, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (724, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (725, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (726, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (726, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (726, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (727, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (727, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (728, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (728, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (728, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (729, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (729, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (730, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (730, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (731, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (732, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (733, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (734, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (734, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (735, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (735, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (736, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (736, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (737, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (738, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (738, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (739, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (740, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (741, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (741, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (741, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (742, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (743, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (743, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (744, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (744, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (744, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (745, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (745, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (745, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (746, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (746, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (747, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (747, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (748, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (749, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (750, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (750, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (750, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (751, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (751, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (751, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (752, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (752, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (753, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (753, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (754, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (754, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (754, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (755, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (756, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (757, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (758, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (759, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (760, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (760, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (760, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (761, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (761, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (761, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (762, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (763, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (763, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (763, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (764, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (764, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (765, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (765, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (766, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (766, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (766, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (767, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (767, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (768, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (769, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (769, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (769, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (770, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (771, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (771, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (772, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (773, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (774, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (775, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (775, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (776, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (776, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (777, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (778, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (778, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (778, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (779, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (779, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (779, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (780, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (781, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (782, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (783, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (784, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (784, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (784, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (785, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (786, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (786, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (787, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (787, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (788, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (788, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (789, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (790, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (790, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (790, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (791, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (792, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (792, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (793, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (793, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (793, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (794, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (795, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (795, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (796, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (797, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (797, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (797, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (798, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (798, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (798, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (799, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (799, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (799, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (800, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (801, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (801, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (802, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (802, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (803, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (803, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (804, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (804, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (804, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (805, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (805, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (806, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (806, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (807, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (807, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (808, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (808, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (808, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (809, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (809, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (810, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (810, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (810, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (811, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (811, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (811, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (812, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (812, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (813, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (813, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (813, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (814, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (814, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (815, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (815, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (816, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (817, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (818, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (819, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (820, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (820, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (821, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (821, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (822, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (823, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (823, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (823, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (824, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (824, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (825, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (825, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (825, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (826, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (827, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (827, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (828, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (828, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (828, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (829, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (829, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (829, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (830, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (831, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (831, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (832, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (832, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (832, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (833, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (833, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (834, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (834, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (834, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (835, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (836, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (837, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (837, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (837, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (838, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (838, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (838, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (839, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (839, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (839, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (840, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (841, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (841, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (842, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (842, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (843, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (844, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (844, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (845, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (845, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (845, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (846, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (847, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (847, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (848, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (848, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (848, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (849, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (850, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (850, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (850, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (851, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (851, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (851, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (852, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (852, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (852, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (853, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (854, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (854, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (855, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (855, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (856, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (856, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (856, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (857, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (857, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (857, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (858, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (858, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (859, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (860, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (861, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (862, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (862, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (862, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (863, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (864, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (864, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (865, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (865, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (866, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (867, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (867, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (868, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (868, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (868, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (869, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (869, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (870, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (871, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (871, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (871, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (872, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (873, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (873, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (874, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (874, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (874, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (875, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (876, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (876, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (876, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (877, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (877, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (878, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (879, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (879, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (880, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (880, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (881, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (882, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (882, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (882, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (883, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (884, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (884, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (885, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (885, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (885, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (886, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (886, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (887, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (887, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (888, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (888, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (888, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (889, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (889, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (889, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (890, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (890, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (890, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (891, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (891, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (891, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (892, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (892, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (892, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (893, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (893, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (893, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (894, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (894, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (895, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (896, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (896, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (896, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (897, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (897, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (898, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (898, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (899, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (899, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (900, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (900, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (901, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (901, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (902, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (903, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (903, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (903, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (904, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (904, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (904, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (905, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (906, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (906, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (906, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (907, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (908, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (908, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (908, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (909, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (909, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (909, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (910, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (910, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (911, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (912, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (913, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (914, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (914, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (915, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (915, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (916, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (917, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (917, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (918, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (918, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (918, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (919, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (919, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (920, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (921, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (922, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (923, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (923, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (923, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (924, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (924, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (924, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (925, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (925, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (925, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (926, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (926, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (927, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (928, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (929, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (930, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (931, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (931, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (932, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (933, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (933, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (934, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (934, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (935, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (936, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (936, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (937, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (937, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (938, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (938, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (938, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (939, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (939, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (940, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (941, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (941, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (941, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (942, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (942, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (943, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (944, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (944, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (945, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (945, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (946, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (946, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (946, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (947, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (948, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (948, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (948, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (949, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (950, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (950, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (950, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (951, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (951, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (952, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (952, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (953, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (953, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (953, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (954, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (954, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (955, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (956, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (956, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (957, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (957, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (957, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (958, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (959, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (959, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (960, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (960, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (961, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (961, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (961, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (962, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (963, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (963, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (964, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (964, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (964, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (965, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (965, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (965, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (966, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (966, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (966, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (967, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (967, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (968, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (968, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (968, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (969, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (969, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (970, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (970, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (970, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (971, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (971, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (972, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (973, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (974, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (975, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (976, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (976, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (976, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (977, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (977, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (977, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (978, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (979, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (979, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (980, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (980, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (980, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (981, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (982, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (982, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (982, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (983, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (984, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (984, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (985, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (986, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (986, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (987, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (987, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (987, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (988, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (988, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (989, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (990, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (990, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (990, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (991, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (991, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (991, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (992, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (992, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (993, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (993, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (994, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (995, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (996, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (996, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (996, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (997, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (997, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (997, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (998, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (999, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (999, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (999, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1000, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1000, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1001, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1002, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1002, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1003, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1003, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1003, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1004, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1004, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1004, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1005, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1005, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1006, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1007, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1007, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1008, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1008, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1008, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1009, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1010, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1010, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1011, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1012, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1013, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1013, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1013, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1014, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1015, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1015, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1015, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1016, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1017, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1017, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1017, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1018, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1018, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1019, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1019, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1019, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1020, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1020, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1021, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1022, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1023, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1023, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1024, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1025, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1025, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1026, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1027, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1027, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1027, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1028, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1028, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1029, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1029, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1029, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1030, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1030, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1030, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1031, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1031, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1032, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1032, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1033, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1034, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1034, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1035, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1035, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1035, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1036, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1036, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1036, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1037, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1038, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1038, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1038, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1039, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1039, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1039, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1040, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1040, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1040, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1041, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1041, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1041, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1042, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1042, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1043, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1043, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1044, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1044, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1044, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1045, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1045, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1046, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1046, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1047, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1047, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1048, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1048, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1049, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1049, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1050, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1050, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1051, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1051, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1052, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1052, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1052, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1053, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1053, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1054, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1055, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1055, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1055, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1056, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1056, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1057, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1058, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1058, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1059, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1059, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1060, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1060, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1061, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1061, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1062, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1063, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1063, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1064, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1064, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1064, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1065, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1065, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1065, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1066, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1067, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1067, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1067, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1068, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1068, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1069, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1070, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1070, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1070, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1071, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1072, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1072, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1072, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1073, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1073, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1073, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1074, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1074, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1074, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1075, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1075, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1075, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1076, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1077, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1078, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1079, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1079, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1079, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1080, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1080, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1081, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1081, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1082, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1083, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1083, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1083, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1084, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1085, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1085, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1085, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1086, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1087, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1088, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1088, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1088, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1089, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1089, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1090, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1091, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1091, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1091, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1092, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1092, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1093, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1093, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1093, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1094, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1095, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1096, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1096, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1097, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1097, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1098, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1098, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1098, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1099, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1099, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1099, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1100, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1100, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1101, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1101, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1102, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1102, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1103, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1104, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1104, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1104, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1105, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1105, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1105, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1106, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1107, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1107, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1107, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1108, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1109, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1109, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1109, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1110, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1110, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1111, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1111, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1111, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1112, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1113, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1113, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1114, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1114, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1114, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1115, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1116, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1116, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1117, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1118, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1119, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1119, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1120, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1121, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1122, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1122, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1122, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1123, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1124, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1124, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1125, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1125, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1125, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1126, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1127, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1128, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1129, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1129, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1129, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1130, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1130, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1131, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1131, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1132, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1133, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1133, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1134, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1135, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1136, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1137, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1137, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1137, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1138, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1138, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1139, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1140, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1140, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1140, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1141, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1142, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1143, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1143, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1144, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1145, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1146, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1146, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1147, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1147, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1147, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1148, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1149, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1149, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1150, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1150, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1151, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1152, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1153, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1153, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1154, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1154, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1154, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1155, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1155, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1156, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1157, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1157, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1157, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1158, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1158, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1158, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1159, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1159, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1159, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1160, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1161, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1161, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1162, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1163, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1163, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1164, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1164, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1165, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1166, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1166, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1167, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1168, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1168, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1168, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1169, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1170, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1171, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1171, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1172, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1172, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1173, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1174, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1175, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1175, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1176, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1176, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1176, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1177, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1177, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1178, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1178, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1178, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1179, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1179, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1179, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1180, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1180, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1181, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1181, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1182, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1182, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1182, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1183, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1183, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1183, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1184, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1184, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1185, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1186, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1186, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1187, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1187, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1187, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1188, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1188, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1189, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1189, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1189, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1190, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1191, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1191, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1191, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1192, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1193, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1193, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1193, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1194, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1195, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1195, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1195, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1196, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1196, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1196, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1197, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1198, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1199, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1199, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1199, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1200, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1200, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1201, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1201, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1202, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1203, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1204, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1204, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1204, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1205, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1206, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1206, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1207, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1207, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1208, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1209, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1209, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1210, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1210, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1210, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1211, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1211, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1211, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1212, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1212, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1212, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1213, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1213, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1214, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1214, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1215, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1215, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1215, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1216, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1217, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1217, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1217, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1218, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1218, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1219, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1220, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1220, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1220, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1221, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1221, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1222, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1222, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1223, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1223, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1224, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1225, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1225, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1225, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1226, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1227, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1228, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1228, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1228, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1229, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1229, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1229, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1230, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1230, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1231, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1231, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1232, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1232, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1233, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1233, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1234, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1235, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1235, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1235, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1236, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1237, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1238, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1239, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1240, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1240, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1241, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1242, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1242, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1243, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1243, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1244, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1244, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1245, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1245, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1245, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1246, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1247, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1247, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1248, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1248, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1249, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1249, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1250, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1250, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1251, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1252, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1252, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1253, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1253, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1254, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1254, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1254, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1255, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1255, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1256, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1256, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1256, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1257, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1257, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1258, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1258, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1259, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1260, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1261, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1261, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1262, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1262, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1263, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1263, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1264, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1264, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1264, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1265, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1265, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1265, 33);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1266, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1267, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1268, 7);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1268, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1268, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1269, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1270, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1271, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1272, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1272, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1272, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1273, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1274, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1274, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1274, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1275, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1275, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1275, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1276, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1276, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1276, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1277, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1277, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1277, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1278, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1278, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1279, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1280, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1281, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1281, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1281, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1282, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1282, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1282, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1283, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1283, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1284, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1285, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1285, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1285, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1286, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1286, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1286, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1287, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1288, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1288, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1288, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1289, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1289, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1289, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1290, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1290, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1291, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1291, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1291, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1292, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1293, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1293, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1293, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1294, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1294, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1295, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1296, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1296, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1297, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1297, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1298, 60);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1299, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1300, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1300, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1300, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1301, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1301, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1301, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1302, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1302, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1303, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1303, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1304, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1304, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1305, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1305, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1305, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1306, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1307, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1307, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1307, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1308, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1308, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1309, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1309, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1310, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1310, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1311, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1312, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1312, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1313, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1314, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1314, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1315, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1315, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1316, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1317, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1318, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1318, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1319, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1319, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1319, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1320, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1321, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1321, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1321, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1322, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1322, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1322, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1323, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1324, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1325, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1326, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1326, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1326, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1327, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1327, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1327, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1328, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1328, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1328, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1329, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1329, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1330, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1330, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1330, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1331, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1331, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1332, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1332, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1332, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1333, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1333, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1334, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1334, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1334, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1335, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1335, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1335, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1336, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1336, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1336, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1337, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1337, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1337, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1338, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1338, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1338, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1339, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1339, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1339, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1340, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1340, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1340, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1341, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1341, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1342, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1343, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1344, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1345, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1346, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1347, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1347, 62);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1347, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1348, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1349, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1349, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1349, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1350, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1350, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1350, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1351, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1351, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1351, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1352, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1352, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1353, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1354, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1355, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1355, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1356, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1356, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1357, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1358, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1358, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1359, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1360, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1360, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1360, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1361, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1361, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1361, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1362, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1362, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1362, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1363, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1363, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1364, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1364, 73);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1364, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1365, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1366, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1366, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1367, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1367, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1368, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1368, 48);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1369, 55);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1369, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1369, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1370, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1370, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1370, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1371, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1371, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1371, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1372, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1373, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1374, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1375, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1376, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1376, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1376, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1377, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1377, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1377, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1378, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1378, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1378, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1379, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1379, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1380, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1380, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1380, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1381, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1381, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1382, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1382, 24);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1383, 97);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1384, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1385, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1385, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1386, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1386, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1387, 92);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1387, 56);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1387, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1388, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1388, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1388, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1389, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1389, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1389, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1390, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1390, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1391, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1391, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1391, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1392, 58);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1393, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1393, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1393, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1394, 9);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1394, 65);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1394, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1395, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1396, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1396, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1397, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1397, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1398, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1398, 84);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1398, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1399, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1399, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1400, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1400, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1400, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1401, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1401, 80);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1402, 54);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1402, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1403, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1403, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1403, 11);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1404, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1404, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1404, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1405, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1405, 85);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1406, 16);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1406, 42);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1407, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1408, 74);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1408, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1409, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1409, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1409, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1410, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1411, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1411, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1411, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1412, 23);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1413, 50);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1414, 34);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1415, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1415, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1416, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1416, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1417, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1418, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1419, 35);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1419, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1420, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1420, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1421, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1422, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1422, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1423, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1424, 1);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1424, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1424, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1425, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1425, 98);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1425, 79);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1426, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1426, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1427, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1427, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1428, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1428, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1429, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1430, 40);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1431, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1431, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1432, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1432, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1433, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1433, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1434, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1435, 76);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1436, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1436, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1437, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1438, 83);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1438, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1439, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1440, 88);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1440, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1441, 87);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1441, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1442, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1442, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1442, 90);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1443, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1444, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1445, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1446, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1446, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1446, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1447, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1448, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1449, 75);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1450, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1451, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1451, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1452, 82);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1452, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1452, 100);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1453, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1453, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1453, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1454, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1454, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1454, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1455, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1455, 94);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1455, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1456, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1456, 29);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1456, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1457, 99);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1458, 28);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1458, 44);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1458, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1459, 6);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1459, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1459, 53);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1460, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1460, 68);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1460, 15);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1461, 47);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1461, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1461, 69);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1462, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1462, 57);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1463, 20);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1463, 30);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1464, 59);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1465, 31);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1466, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1466, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1466, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1467, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1467, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1468, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1469, 8);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1469, 49);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1470, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1470, 25);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1470, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1471, 46);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1471, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1471, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1472, 17);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1472, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1473, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1474, 95);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1475, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1475, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1476, 19);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1476, 5);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1477, 12);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1478, 27);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1478, 96);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1478, 52);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1479, 43);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1479, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1479, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1480, 93);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1481, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1481, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1482, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1483, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1483, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1483, 86);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1484, 21);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1484, 38);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1484, 89);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1485, 51);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1485, 14);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1485, 10);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1486, 3);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1487, 36);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1487, 26);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1488, 64);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1488, 4);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1489, 91);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1489, 61);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1490, 70);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1490, 2);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1490, 41);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1491, 67);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1492, 78);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1492, 37);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1493, 32);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1494, 81);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1494, 66);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1494, 18);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1495, 39);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1495, 71);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1496, 45);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1497, 77);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1497, 13);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1498, 72);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1498, 63);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1498, 22);
                
                INSERT INTO Autor_Kurs (ID_Kurs, ID_Autor)
                VALUES (1499, 37);
                