import { Ticket } from './ticket';

export interface Tickets {
  tickets: Ticket[];
}
