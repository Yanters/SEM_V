export interface CreateTicket {
  reason: string;
  price: number;
}
