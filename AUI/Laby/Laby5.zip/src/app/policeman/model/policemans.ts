import { Policeman } from './policeman';

export interface Policemans {
  policemans: Policeman[];
}
