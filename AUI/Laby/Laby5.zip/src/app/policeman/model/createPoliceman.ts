export interface CreatePoliceman {
  name: string;
  rank: number;
}
