import { CreatePoliceman } from './createPoliceman';

export interface Policeman extends CreatePoliceman {
  id: string;
}
